<?php
/**
 * Created by PhpStorm.
 * User: Admin
 * Date: 1/12/2019
 * Time: 11:32 PM
 */

include "auth/db.php";

echo "<h1>Hello world!</h1>";
//echo phpinfo();

?>

